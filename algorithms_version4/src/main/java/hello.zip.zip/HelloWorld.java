/**
 * @Description
 * @Author Administrator
 * @Date 2024/7/1 23:34
 **/
public class HelloWorld {

    public static void main(String[] args) {
        System.out.println("Hello, World");
    }
}
